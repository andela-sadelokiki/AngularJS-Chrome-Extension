(function($){
  $(function(){

    $('.button-collapse').sideNav();

  }); // end of document ready
}); // end of jQuery name space